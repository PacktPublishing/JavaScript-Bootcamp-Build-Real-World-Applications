// Lecture: Events - Part 1

/*
var h2 = document.querySelector('header h2');

// h2.onclick = function() {
//     console.log('Clicked');
// }

// h2.onmouseover = function() {
//     console.log('Mouseover');
// }

// function a() {
//     console.log('Clicked');
// }
// function b() {
//     console.log('Mouseover');
// }

function a() {
    console.log('Clicked a');
}
function b() {
    console.log('Clicked b');
}
*/





