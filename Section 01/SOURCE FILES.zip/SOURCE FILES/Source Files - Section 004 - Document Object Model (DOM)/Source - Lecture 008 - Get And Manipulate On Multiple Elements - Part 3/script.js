// Lecture: Get And Manipulate On Multiple Elements - Part 3

/*
var lis = document.querySelectorAll('li, h2, #hide-list');
console.log(lis);
// // lis.push('Hello');

// lis.forEach(function(li) {
//     console.log(li);
// });

Array.from(lis).forEach(function(li) {
    li.textContent = "Hello World";
});
*/







