// Lecture: DOM Navigation

/*
var listItem = document.getElementById('list-item');

console.log(listItem.parentNode);
console.log(listItem.parentNode.parentNode);
console.log(listItem.parentElement);
console.log(listItem.parentElement.style.background = 'orange');
console.log(listItem.childNodes);
console.log(listItem.children);
console.log(listItem.firstChild);
console.log(listItem.firstElementChild);
console.log(listItem.lastChild);
console.log(listItem.lastElementChild);
console.log(listItem.previousSibling);
console.log(listItem.previousElementSibling);
console.log(listItem.nextElementSibling);
*/


















