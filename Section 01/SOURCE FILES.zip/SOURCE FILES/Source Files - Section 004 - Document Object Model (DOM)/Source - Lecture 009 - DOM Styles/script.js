// Lecture: DOM Styles

/*
// var h2 = document.querySelector('header h2');
// console.log(h2);

// console.log(h2.style.color = 'red');
// // console.log(h2.style.background-color = 'green');
// console.log(h2.style.backgroundColor = 'green');

var lis = document.querySelectorAll('ul li');
// console.log(lis[1].style.backgroundColor = 'red');
for(var i = 0; i < lis.length; i++) {
    console.log(lis[i].style.backgroundColor = 'blue');
}

console.log(lis[0].style.cssText = 'background-color: yellow; font-size: 25px;');
*/

