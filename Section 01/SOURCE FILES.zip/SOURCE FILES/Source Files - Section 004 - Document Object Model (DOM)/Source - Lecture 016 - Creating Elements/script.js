// Lecture: Creating Elements

/*
var newEl = document.createElement('button');

// console.log(newEl);

var text = document.createTextNode('Click');

// console.log(text);

newEl.appendChild(text);

newEl.setAttribute('style', 'display: block; margin: 10px auto; padding: 5px 10px; background: coral; color: #fff;');

console.log(newEl);

var form = document.getElementById('add');

// form.appendChild(newEl);

form.insertBefore(newEl, form.children[0]);

newEl.parentElement.removeChild(newEl);
*/













