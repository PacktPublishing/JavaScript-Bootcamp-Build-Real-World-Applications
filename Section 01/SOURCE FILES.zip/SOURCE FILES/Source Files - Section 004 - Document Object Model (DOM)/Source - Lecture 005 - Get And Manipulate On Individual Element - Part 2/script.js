// Lecture: Get And Manipulate On Individual Elements - Part 2

/*
// var el = document.querySelector('ul');
// console.log(el);
// console.log(el.textContent = 'Hello World');

// var el = document.querySelector('#search-note');
// console.log(el);

// var el = document.querySelector('ul li');
// console.log(el);

// var el = document.querySelector('ul li:nth-child(2)');
// console.log(el);

// console.log(el.querySelector('p .fa-times'));
*/









