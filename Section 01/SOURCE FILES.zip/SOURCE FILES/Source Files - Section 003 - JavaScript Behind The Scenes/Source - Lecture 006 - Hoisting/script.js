// Lecture: Hoisting

/*
// console.log(a);
// console.log(b());
var a = 10;

function b() {
  return 20;
}

// var b = function() {
//   return 20;
// }

console.log(a);
console.log(b());


if(true) {
  var a = 10;
} else {
  var b = 20;
} 

console.log(a);
console.log(b);
*/








