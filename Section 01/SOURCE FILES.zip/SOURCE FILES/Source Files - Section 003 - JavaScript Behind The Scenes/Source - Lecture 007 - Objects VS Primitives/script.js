// Lecture: Objects VS Primitives

/*
var a = 10;
var b = a;
a = 20;

console.log(a);
console.log(b);

console.log(window);

var c = {
  name: 'John'
};
var d = c;
c.name = 'Nick';

c = {
  name: 'Bob'
};

console.log(window);
*/







