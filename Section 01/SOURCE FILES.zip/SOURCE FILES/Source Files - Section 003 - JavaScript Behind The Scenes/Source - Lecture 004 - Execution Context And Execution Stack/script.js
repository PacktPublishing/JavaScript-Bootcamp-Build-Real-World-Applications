// Lecture: Execution Context And Execution Stack

/*
function a() {
  var name = 'John';
  b();
  console.log(name);
}
function b() {
  var name = 'Bob';
  c();
  console.log(name);
}
function c() {
  var name = 'Nick';
  console.log(name);
}

a();

function a() {
  a();
}

a();
*/













