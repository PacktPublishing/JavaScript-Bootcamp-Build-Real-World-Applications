// Lecture: JavaScript Behind The Scenes - Introduction

/*
var a = 'Hello';
console.log(a);

function b {

}
*/





