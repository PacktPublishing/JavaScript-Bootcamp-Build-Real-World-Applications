// Lecture: Objects - Part 1

/*
var person = new Object();

// var job = 'profession';

// var name = 'firstname';

// person.name = 'John';

// person.name = 'Bob';

// person[job] = 'instructor';

// console.log(person);

// console.log(person.firstname);

// console.log(person['lastname']);

person.firstname = 'John';

person.lastname = 'Smith';

person.son = new Object();

person.son.name = 'Nick';

person.son.age = 5;

console.log(person);
*/


















