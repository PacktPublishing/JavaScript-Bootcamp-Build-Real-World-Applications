// Lecture: Loops - Part 2

/*
// var i = 0;

// while(i <= 10) {
    
//     // i++;
//     console.log(i);
//     i++;

// }

var colors = ['white', 'red', 'green', 'blue'];

var i = 0;

// while(i < colors.length) {

//     // i++;
//     console.log(colors[i]);
//     i++;

// }

do {
    
    console.log(colors[i]);
    i++

} while(i < colors.length);
*/

























