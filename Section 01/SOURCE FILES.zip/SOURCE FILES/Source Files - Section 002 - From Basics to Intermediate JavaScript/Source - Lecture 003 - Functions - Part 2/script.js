// Lecture: Functions - Part 2

/*
function add(a, b) {

    console.log(a + b);

}

add(5, 10);

var sum = function(a, b) {

    console.log(a + b);

}

sum(10, 15);
*/


























