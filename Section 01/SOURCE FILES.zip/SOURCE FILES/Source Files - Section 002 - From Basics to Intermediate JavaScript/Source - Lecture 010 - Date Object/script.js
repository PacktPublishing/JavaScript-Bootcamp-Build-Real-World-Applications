// Lecture: Date Object

/*
// var date = new Date('January 20, 2020 10:14:00');

// console.log(date);

var date = new Date();

var year = date.getFullYear();

var month = date.getMonth();

var x = date.setFullYear(1990);

date.setMonth(11);

console.log(date);
console.log(year);
console.log(month);
console.log(x);
*/






















