// Lecture: Array Helpers - map()

/*
var numbers = [1, 2, 3, 4, 5];

var newArr = [];

for(var i = 0; i < numbers.length; i++) {

    newArr.push(numbers[i] * 10);

}

console.log(numbers);

console.log(newArr);

console.log('------------------');

var mapArr = numbers.map(function(number) {

    return number * 10;

});

console.log(numbers);

console.log(mapArr);

console.log('--------------------------');

var persons = [
    {firstname: 'John', lastname: 'Smith'},
    {firstname: 'Bob', lastname: 'Brown'},
    {firstname: 'Nick', lastname: 'Doe'}
];

var getFirstNames = persons.map(function(person) {

    return person.firstname;

});

console.log(persons);

console.log(getFirstNames);
*/






























