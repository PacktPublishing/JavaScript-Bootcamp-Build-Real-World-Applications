// Lecture: Array Helpers - every() / some()

/*
var persons = [
    {firstname: 'John', age: 28},
    {firstname: 'Mary', age: 20},
    {firstname: 'Nick', age: 25},
    {firstname: 'Jane', age: 40}
];

var everyPersonCanVote = true;

var onlySomePersonsCanVote = false;

for(var i = 0; i < persons.length; i++) {

    if(persons[i].age < 18) {

        everyPersonCanVote = false;

        onlySomePersonsCanVote = true;

    }

}

console.log('Every person can vote - ' + everyPersonCanVote);

console.log('Only some persons can vote - ' + onlySomePersonsCanVote);

var x = 0;

var every = persons.every(function(person) {

    console.log(++x + ' - ' + (person.age >= 18));

    return person.age >= 18;

});

console.log(every);
*/















