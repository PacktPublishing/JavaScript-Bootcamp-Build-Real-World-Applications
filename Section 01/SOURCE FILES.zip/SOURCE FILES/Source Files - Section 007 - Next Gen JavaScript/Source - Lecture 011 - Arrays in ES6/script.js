// Lecture: Arrays in ES6

/*
const lis = document.getElementsByTagName('li');

// console.log(lis);

// const lisArr = Array.prototype.slice.call(lis);

// console.log(lisArr);

// const lisArr = Array.from(lis);

// console.log(lisArr);

// Array.from(lis).forEach(li => {

//     li.addEventListener('click', () => {

//         li.classList.toggle('change');

//     });

// });

for(let li of lis) {

    li.addEventListener('click', () => {

        li.classList.toggle('change');

    });

}
*/











































