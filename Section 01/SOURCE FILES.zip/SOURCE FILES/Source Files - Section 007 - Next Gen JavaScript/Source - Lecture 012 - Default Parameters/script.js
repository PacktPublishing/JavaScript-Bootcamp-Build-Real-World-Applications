// Lecture: Default Parameters

/*
// function person(firstname, lastname, profession) {

//     if(lastname === undefined) {

//         lastname = 'Smith';

//     }

//     // if(profession === undefined) {

//     //     profession = 'programmer';

//     // }

//     profession = profession || 'programmer';

//     console.log(`I am ${firstname} ${lastname} and I am ${profession}`);

// }

// person('John', 'Doe');


function person(firstname = 'John', lastname = 'Smith', profession = 'programmer') {

    console.log(`I am ${firstname} ${lastname} and I am ${profession}`);

}

// person();
person('Nick', 'Doe', 'instuctor');
*/




















































































































