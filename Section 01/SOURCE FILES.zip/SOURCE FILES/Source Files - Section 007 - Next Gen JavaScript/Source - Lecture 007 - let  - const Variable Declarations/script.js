// Lecture: let / const Variable Declarations

/*
// var name = 'John';

// var age = 28;

// name = 'Nick';

// age = 29;

// console.log(name, age);

// const name = 'John';

// let age = 28;

// name = 'Nick';

// age = 29;

// console.log(name, age);

// let person = 'John Smith';

// let person = 'Nick Doe';

// console.log(person);

// let person = 'John Smith';

// function a() {

//     var b = 'Hello';
//     // const b = 'Hello';
//     // let b = 'Hello';

// }

// console.log(b);

// let firstname = 'Nick';

// if(true) {

//     let firstname = 'John';
//     console.log(firstname);

// }

// console.log(firstname);

// let firstname = 'Nick';

// const person = {
//     name: 'Jane',
//     age: 18
// };

// if(true) {

//     firstname = 'John';

//     person.age = 19;

// }

// console.log(firstname);

// for(let i = 0; i < 5; i++) {

//     setTimeout(function () {

//         console.log(i);

//     }, i * 500);

//     console.log(i);

// }

// console.log(i);

// (function() {
    
//     var a = 10;

// })();

// {
//     let b = 30;
//     // const b = 30;
//     // var b = 30;
// }

// console.log(b);
*/

























