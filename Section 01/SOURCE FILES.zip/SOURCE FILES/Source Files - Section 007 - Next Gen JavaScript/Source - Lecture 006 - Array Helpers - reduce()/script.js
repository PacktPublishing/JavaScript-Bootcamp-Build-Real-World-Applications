// Lecture: Array Helpers - reduce()

/*
var numbers = [100, 200, 300];

var sum = 0;

for(var i = 0; i < numbers.length; i++) {

    sum += numbers[i];

}

console.log(sum);

console.log('-------------------------');

var total = numbers.reduce(function(previous, number) {
    return previous + number;
}, 0);

console.log(total);

console.log('-----------------------');

var weeklyEarnings = [750, 642, 823, 1456];

var income = weeklyEarnings.reduce(function(previous, weeklyEarning) {

    return previous + weeklyEarning;

}, 5000);

console.log(income);

console.log('---------------------------');

var firstnames = ['John', 'Jane', 'Mary'];

var lastnames = ['Smith', 'Brown', 'Doe'];

var fullnames = firstnames.reduce(function(previous, firstname, index) {

    previous.push(firstname + ' ' + lastname[index]);

    return previous;

}, []);

console/log(fullnames);
*/






