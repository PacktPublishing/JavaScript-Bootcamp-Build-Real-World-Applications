// Lecture: Destructuring

/*
const arr = [10, 20, 30, 40, 50, 60];

// const ten = arr[0];

// const twenty = arr[1];

// const [ten, twenty, ...items] = arr;

// console.log(ten, twnety, ...items);

const person = {
    firstname: 'John',
    lastname: 'Smith',
    age: 30
};

// const a = person.firstname;

// const b = person.lastname;

// const {age, firstname, lastname} = person;

// console.log(age, firstname, lastname);

// const aboutMe = john => {

//     const {firstname, lastname, age} = john;

//     console.log(`I am ${firstname} ${lastname} and I am ${age} years old`);

// }

// aboutMe(person);

const aboutMe = ({firstname, lastname, age}) => {

    console.log(`I am ${firstname} ${lastname} and I am ${age} years old`);

}

aboutMe(person);
*/
















































































