// Lecture: Array Helpers - filter() / find()

/*
var persons = [
    {firstname: 'Mary', gender: 'female'},
    {firstname: 'Mary', gender: 'female'},
    {firstname: 'Mary', gender: 'female'},
    {firstname: 'Mary', gender: 'female'}
];

var males = [];

for(var i = 0; i < persons.length; i++) {

    if(persons[i].gender === 'male') {
       
        males.push(persons[i]);
        // break;
    
    }

}

console.log(persons);

console.log(males);

console.log('------------------------');
                                //find()
var females = persons.filter(function(person) {

    return person.gender === 'female';

});

console.log(persons);

console.log(females);
*/























