// Lecture: Arrow Functions - Part 1

/*
// const multiply = function(x, y) {

//     let z = x * y;

//     return z;

// }

// console.log(multiply(5, 6));

// const multiply = (x, y) => x * y;

// console.log(multiply(5, 6));

// const multiply = () => 5 * 10;

// console.log(multiply());

// const multiply = () => ({firstname: 'John'});

// console.log(multiply());
*/


































