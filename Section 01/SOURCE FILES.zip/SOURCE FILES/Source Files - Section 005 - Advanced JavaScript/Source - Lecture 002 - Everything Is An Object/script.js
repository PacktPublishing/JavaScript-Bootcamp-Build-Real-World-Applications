// Lecture: Everything Is An Object

/*
// var arr = [1, 2, 3];
// arr[3] = 4;

// arr.prop = 'Hello';

// console.log(arr);
// console.log(arr.prop);

// function a() {
//   console.log('Hello');
// }

// a['prop'] = 'Hi';

// a.obj = {
//   greet: 'Hey'
// };

// a.myFunc = function() {
//   console.log('Hola');
// }

// console.log(window);
*/


















