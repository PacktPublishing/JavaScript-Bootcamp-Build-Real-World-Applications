// Lecture: Function Constructor

/*
var person1 = {};
person1.firstname = 'John';
person1.lastname = 'Smith';

var person2 = {};
person2.firstname = 'Nick';
person2.lastname = 'Doe';

// function createPerson() {
//   var newPerson = {};
//   newPerson.firstname = 'Bob';
//   newPerson.lastname = 'Brown';
//   return newPerson;
// }

// function createPerson(firstname, lastname) {
//   var newPerson = {};
//   newPerson.firstname = firstname;
//   newPerson.lastname = lastname;
//   return newPerson;
// }

function Person(firstname, lastname) {
  
  this.firstname = firstname;
  this.lastname = lastname;
  
}

var person3 = new Person('Bob', 'Brown');
var person4 = new Person('Mary', 'James');

// console.log(this);
console.log(person1);
console.log(person2);
console.log(person3);
console.log(person4);

var strObj = new String('Hello');
console.log(strObj);
console.log(typeof strObj);
*/
















