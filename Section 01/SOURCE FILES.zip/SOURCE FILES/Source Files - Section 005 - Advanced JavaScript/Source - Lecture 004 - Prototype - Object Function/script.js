// Lecture: Prototype - Object Function

/*
var a = {};
var b = new Object();

console.log(a);
console.log(b);
console.log(Object);
console.log(Object.prototype);

Object.prototype.greet = 'Hello';
console.log(Object.prototype);
*/















