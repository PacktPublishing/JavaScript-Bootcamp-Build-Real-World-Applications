// Lecture - Type Coercion

/*
var a = 10 + 5;
console.log(a);

var a = 10 + '5';
console.log(a);

var b = 'Hello ' + ' dear ' + 'student';
console.log(b);

var a = 10 * '5';
console.log(a);

var a = 5 + 10 + 'b';
console.log(a);

var c = 'b' + 5 + 10;
console.log(c);

console.log(5 === 5);
console.log(5 === 5 === 5);
console.log(true === 5);
console.log(true == 1);
console.log(false == 0);
*/









