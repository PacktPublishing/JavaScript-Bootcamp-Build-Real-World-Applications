// Lecture - Comparison Operators

/*
var a = 5;
var b = 5;
console.log(a == b);

var a = 5;
var b = '5';
console.log(a == b);
console.log(a === b);

var a = 5;
var b = 5;
console.log(a != b);

var a = 5;
var b = '5';
console.log(a != b);
console.log(a !== b);
*/