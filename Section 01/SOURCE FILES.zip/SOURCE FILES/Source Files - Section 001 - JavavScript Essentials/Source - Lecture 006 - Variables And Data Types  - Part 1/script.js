// Lecture - Variables And Data Types - Part 1
/*
var person = 'instructor';
console.log(person);

person = 'teacher';
console.log(person);

var firstName = 'John', 
    lastName = 'Doe', 
    age = 27;
*/















