// Lecture - Conditional Statements

/*
// if statement
var myChild = 'Alexis';
var gender = 'male';
// var gender = 'female';

if(gender === 'male') {
  console.log(myChild + ' is my son ');
} else {
  console.log(myChild + ' is my daughter');
}
*/








