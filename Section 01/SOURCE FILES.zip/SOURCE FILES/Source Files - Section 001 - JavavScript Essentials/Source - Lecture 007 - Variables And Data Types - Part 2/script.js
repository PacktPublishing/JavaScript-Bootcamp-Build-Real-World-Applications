// Lecture - Variables And Data Types - Part 2

/*
// Strings
var str = "John is an 'Instructor'";
console.log(str);

// Numbers
var num = 27.23;
console.log(num);

// Booleans
var num1 = 5;
var num2 = 10;
console.log(num1 < num2);
console.log(num1 > num2);

// Undefined
var a;
console.log(a);

// Null
var a = null;
console.log(a);
*/





